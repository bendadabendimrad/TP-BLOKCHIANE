export { default as Ex1 } from "./Ex1";
export { default as Ex2 } from "./Ex2";
export { default as Ex3 } from "./Ex3";
export { default as Ex4 } from "./Ex4";
export { default as Ex5 } from "./Ex5";
export { default as Ex6 } from "./Ex6";
export { default as Ex7 } from "./Ex7";
export { default as Ex8 } from "./Ex8";
