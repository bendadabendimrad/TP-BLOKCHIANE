export const NETWORK_ID = "1746914393389" as const;

export const ExercisesLinks = [
  {
    label: "Somme de deux variables",
    id: 1,
  },

  {
    label: "Conversion des cryptomonnaiers",
    id: 2,
  },

  {
    label: "Tritement des chaines de caractéres",
    id: 3,
  },

  {
    label: "Tester le signe d'une nombre",
    id: 4,
  },
  {
    label: "Tester la parité d'un nombre",
    id: 5,
  },
  {
    label: "Gestion des tableaux ",
    id: 6,
  },
  {
    label: "Programmation Orientée Object (Formes géométriques)",
    id: 7,
  },
  {
    label: "Utilisation des variables globales (msg.sender et msg.value)",
    id: 8,
  },
];
